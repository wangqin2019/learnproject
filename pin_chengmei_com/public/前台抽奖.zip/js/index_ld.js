var init = {
    data:'',
    html:'',
    isTrue:false,
    winner:[],
    randomNum(min,max){ //tool
        return Math.floor(Math.random() * (max - min + 1) + min)
    },
    randomsort(a, b) {
        return Math.random()>.5 ? -1 : 1;
        //用Math.random()函数生成0~1之间的随机数与0.5比较，返回-1或1
    },
    mobileDeel(str){  //处理手机号隐藏中间4位
        return str.substr(0,3)+"****"+str.substr(7)
    },
    randomNumArray(count,maxNum){
        var arr = [];
          for(var coIndex=0;coIndex < count; coIndex++){
                var getNum = this.randomNum(0,maxNum - 1);
              if(arr.length == 0){
                  arr.push(getNum)
              }else{
                  if(arr.indexOf(getNum) == -1){
                      arr.push(getNum);
                  }else{
                    coIndex--
                  }
              }
          }
          return arr
    },
    sliceArray(array, size) { //tool
        var result = [];
        for (var sAindex = 0; sAindex < Math.ceil(array.length / size); sAindex++) {
            var start = sAindex * size;
            var end = start + size;
            result.push(array.slice(start, end));
        }
        return result;
    },
    get_user(){
        $('#num').attr('class','num_div').html('');
        var _this = this,allList = '',dataNum = this.data.num,showNum = this.data.prizeList.length;
        allList = this.data.tickList;
        if(typeof(dataNum) == 'string'){
            dataNum = parseInt(dataNum,10);
        }
        if(showNum == 1){
            $('#num').addClass('font_larges');
        }else if(showNum >= 5 && showNum <= 25){
            $('#num').addClass('font_middle');
        }else{
            $('#num').addClass('font_normal');
        }
        window.newTimer = window.setInterval(function(){
            allList.sort(_this.randomsort);
            _this.html = '';
            for(var s=0;s < allList.length;s++){
                _this.html += `<span>${allList[s].length == 11 ? _this.mobileDeel(allList[s]) : allList[s]}</span>`;
            }
            $('#num').html(_this.html);
        }, 100)
        // var sliceArray = this.sliceArray(allList,dataNum);
        // console.log(sliceArray);
        // window.newTimer = window.setInterval(function(){
        //     var getRandom = _this.randomNum(0,sliceArray.length - 1);
        //     _this.html = '';
        //     for(var s=0;s < sliceArray[getRandom].length;s++){
        //         _this.html += '<span>' + sliceArray[getRandom][s] + '</span>';
        //     }
        //     $('#num').html(_this.html);
        // },100);
    },
    start(data){
        console.log(data);
        this.data = data;
        this.winner = '';
        console.log("winner:")
        console.log(data.prizeList);
        this.winner = data.prizeList;
        this.get_user();
    },
    end(){
        clearInterval(window.newTimer);
        var _this = this;
        this.html = '';
        var winner = this.winner;
        var str = winner.join(',');
        for(var endIndex=0;endIndex < winner.length;endIndex++){
            _this.html += `<span>${winner[endIndex].length == 11 ? _this.mobileDeel(winner[endIndex]) : winner[endIndex]}</span>`;
        }
        $('#num').html(_this.html);
        // $.post("http://172.16.6.163:3366/index/lucky_draw/upDrawList", {
        //     draw_id:_this.data.draw_id
        // }, function (result) {
        //     console.log(result);
        // });
    }
}